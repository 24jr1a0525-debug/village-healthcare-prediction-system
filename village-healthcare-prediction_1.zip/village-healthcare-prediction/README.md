# 🩺 Village Healthcare Disease Prediction System

A Data Science internship project that predicts the most likely disease
based on patient-reported symptoms, aimed at supporting **community
health workers in rural / village healthcare settings** where doctors
and diagnostic facilities are scarce.

## 📌 Problem Statement

In many villages, the nearest doctor or Primary Health Centre (PHC) is
several kilometers away, and basic diagnosis often gets delayed. This
project builds a **Machine Learning-based decision-support tool** that
takes a set of symptoms as input and predicts the most probable
disease(s), helping ASHA / community health workers make faster,
better-informed referral decisions.

## 🎯 Objective

- Predict disease based on reported symptoms using a trained ML model.
- Provide the **top-3 probable diseases** with confidence scores
  (since many diseases share overlapping symptoms).
- Offer a simple CLI and web (Streamlit) interface usable by
  non-technical health workers.

## 🗂️ Project Structure

```
village-healthcare-prediction/
├── data/
│   ├── generate_dataset.py     # Creates the symptom-disease dataset
│   └── village_health_data.csv # Generated dataset (2250 records)
├── model/
│   ├── train_model.py          # Trains & evaluates the ML model
│   ├── disease_model.pkl       # Saved trained model
│   └── symptom_list.pkl        # Ordered symptom feature list
├── app/
│   ├── predict.py              # Command-line prediction tool
│   └── streamlit_app.py        # Web app (Streamlit UI)
├── images/
│   ├── confusion_matrix.png
│   └── feature_importance.png
├── requirements.txt
└── README.md
```

## 🦠 Diseases Covered

Malaria, Dengue, Typhoid, Diarrheal Disease, Common Cold, Influenza,
Tuberculosis, Anemia, Hypertension, Diabetes, Jaundice, Pneumonia,
Skin Infection, Malnutrition, Chickenpox — chosen as they are among
the **most common health issues reported in rural India**.

## 🧬 Symptoms Used (20 features)

fever, headache, chills, vomiting, diarrhea, cough, fatigue,
joint pain, skin rash, weight loss, night sweats, breathlessness,
abdominal pain, dizziness, yellowing skin, excessive thirst,
frequent urination, body ache, sore throat, loss of appetite

## ⚙️ Tech Stack

- **Python 3**
- **Pandas** – data handling
- **Scikit-learn** – Random Forest Classifier
- **Matplotlib / Seaborn** – visualization
- **Streamlit** – web app interface
- **Joblib** – model persistence

## 🔬 Methodology

1. **Data Generation** – Since village-level clinical symptom datasets
   are not publicly available, a medically-informed synthetic dataset
   was generated: each disease is assigned a realistic symptom
   probability profile, and patient records are sampled from these
   profiles with added noise (2250 records, 15 diseases).
2. **Model Training** – A `RandomForestClassifier` (200 trees) is
   trained on an 80/20 train-test split.
3. **Evaluation** – Accuracy, precision/recall, F1-score, and a
   confusion matrix are used to evaluate performance.
4. **Deployment** – The trained model is wrapped in both a CLI tool
   and a Streamlit web app for real-world usability.

## 📊 Results

- **Test Accuracy: ~73%** across 15 disease classes with 20 binary
  symptom features.
- Diseases with distinctive symptom signatures (e.g. Diabetes,
  Dengue, Jaundice) achieve high precision (>0.8).
- Diseases with overlapping general symptoms (e.g. Anemia,
  Hypertension) are harder to distinguish — as expected clinically.

![Confusion Matrix](images/confusion_matrix.png)
![Feature Importance](images/feature_importance.png)

## 🚀 How to Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Generate the dataset
python3 data/generate_dataset.py

# 3. Train the model
python3 model/train_model.py

# 4. Run the command-line predictor
python3 app/predict.py

# 5. OR run the web app
streamlit run app/streamlit_app.py
```

## ⚠️ Disclaimer

This project is built for **academic / internship purposes** as a
decision-support prototype. It is **not a certified medical diagnostic
tool** and should not replace professional medical advice. Serious or
uncertain cases must always be referred to a qualified doctor or the
nearest Primary Health Centre (PHC).

## 🔮 Future Scope

- Train on real, anonymized clinical data from PHCs.
- Add regional language support (voice input) for ASHA workers.
- Integrate with a mobile app for offline use in low-connectivity areas.
- Add severity scoring and automatic referral alerts.

## 👤 Author

Data Science Internship Project — 3rd Year CSE Student
