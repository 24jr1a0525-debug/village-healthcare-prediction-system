"""
predict.py
----------
Simple command-line tool for the Village Healthcare Disease Prediction
System. A health worker enters the patient's symptoms (yes/no) and the
tool predicts the most likely disease along with the top-3 probable
conditions, so the patient can be referred appropriately.

Run:
    python3 app/predict.py
"""

import joblib
import pandas as pd

MODEL_PATH = "model/disease_model.pkl"
SYMPTOM_LIST_PATH = "model/symptom_list.pkl"


def load_model():
    model = joblib.load(MODEL_PATH)
    symptom_list = joblib.load(SYMPTOM_LIST_PATH)
    return model, symptom_list


def get_user_symptoms(symptom_list):
    print("\nAnswer with y/n for each symptom the patient has:\n")
    answers = {}
    for symptom in symptom_list:
        readable = symptom.replace("_", " ")
        while True:
            ans = input(f"  {readable}? (y/n): ").strip().lower()
            if ans in ("y", "n"):
                answers[symptom] = 1 if ans == "y" else 0
                break
            print("  Please enter 'y' or 'n'.")
    return answers


def predict_disease(model, symptom_list, answers):
    X = pd.DataFrame([answers], columns=symptom_list)
    probs = model.predict_proba(X)[0]
    classes = model.classes_
    ranked = sorted(zip(classes, probs), key=lambda x: x[1], reverse=True)
    return ranked


def main():
    print("=" * 60)
    print(" VILLAGE HEALTHCARE - DISEASE PREDICTION SYSTEM")
    print("=" * 60)

    model, symptom_list = load_model()
    answers = get_user_symptoms(symptom_list)
    ranked = predict_disease(model, symptom_list, answers)

    print("\n--- Prediction Result ---")
    print(f"Most likely condition : {ranked[0][0]}  "
          f"(confidence: {ranked[0][1]*100:.1f}%)")

    print("\nTop 3 possible conditions:")
    for disease, prob in ranked[:3]:
        print(f"  - {disease:<20} {prob*100:5.1f}%")

    print("\nNote: This is a decision-support tool for community health "
          "workers, not a substitute for professional diagnosis. "
          "Please refer serious/uncertain cases to the nearest "
          "Primary Health Centre (PHC).")


if __name__ == "__main__":
    main()
