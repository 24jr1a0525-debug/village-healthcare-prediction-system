"""
streamlit_app.py
-----------------
Web UI for the Village Healthcare Disease Prediction System.

Run:
    streamlit run app/streamlit_app.py
"""

import joblib
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Village Healthcare Disease Predictor", page_icon="🩺")


@st.cache_resource
def load_model():
    model = joblib.load("model/disease_model.pkl")
    symptom_list = joblib.load("model/symptom_list.pkl")
    return model, symptom_list


model, symptom_list = load_model()

st.title("🩺 Village Healthcare Disease Prediction System")
st.write(
    "A decision-support tool to help community health workers in rural "
    "areas quickly narrow down the likely disease based on a patient's "
    "symptoms, and decide whether referral to a Primary Health Centre "
    "(PHC) is needed."
)

st.subheader("Select the patient's symptoms")

cols = st.columns(2)
answers = {}
for i, symptom in enumerate(symptom_list):
    col = cols[i % 2]
    label = symptom.replace("_", " ").title()
    answers[symptom] = 1 if col.checkbox(label, key=symptom) else 0

if st.button("Predict Disease", type="primary"):
    if sum(answers.values()) == 0:
        st.warning("Please select at least one symptom.")
    else:
        X = pd.DataFrame([answers], columns=symptom_list)
        probs = model.predict_proba(X)[0]
        classes = model.classes_
        ranked = sorted(zip(classes, probs), key=lambda x: x[1], reverse=True)

        st.success(f"Most likely condition: **{ranked[0][0]}** "
                   f"({ranked[0][1]*100:.1f}% confidence)")

        st.write("### Top 3 probable conditions")
        for disease, prob in ranked[:3]:
            st.write(f"- **{disease}** — {prob*100:.1f}%")
            st.progress(float(prob))

        st.info(
            "⚠️ This tool is a decision-support aid only, not a medical "
            "diagnosis. Please refer serious or uncertain cases to the "
            "nearest Primary Health Centre (PHC)."
        )
