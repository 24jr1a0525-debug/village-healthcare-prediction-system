"""
generate_dataset.py
--------------------
Generates a synthetic but medically-informed symptom -> disease dataset
representative of common diseases seen in rural / village healthcare
settings in India. Each disease has a characteristic symptom profile;
records are sampled with realistic noise so the dataset resembles
real patient records (some symptoms missing, some overlap between diseases).

Output: data/village_health_data.csv
"""

import random
import pandas as pd

random.seed(42)

SYMPTOMS = [
    "fever", "headache", "chills", "vomiting", "diarrhea", "cough",
    "fatigue", "joint_pain", "skin_rash", "weight_loss", "night_sweats",
    "breathlessness", "abdominal_pain", "dizziness", "yellowing_skin",
    "excessive_thirst", "frequent_urination", "body_ache", "sore_throat",
    "loss_of_appetite"
]

# Characteristic symptom probability profile for each disease
# (symptom: probability of occurring for that disease)
DISEASE_PROFILES = {
    "Malaria": {
        "fever": 0.95, "chills": 0.9, "headache": 0.7, "vomiting": 0.5,
        "fatigue": 0.7, "body_ache": 0.6, "loss_of_appetite": 0.4
    },
    "Dengue": {
        "fever": 0.95, "headache": 0.8, "joint_pain": 0.85, "skin_rash": 0.5,
        "fatigue": 0.6, "vomiting": 0.4, "body_ache": 0.7
    },
    "Typhoid": {
        "fever": 0.9, "headache": 0.6, "abdominal_pain": 0.6,
        "loss_of_appetite": 0.7, "fatigue": 0.6, "diarrhea": 0.4
    },
    "Diarrheal Disease": {
        "diarrhea": 0.95, "vomiting": 0.6, "abdominal_pain": 0.7,
        "fatigue": 0.5, "fever": 0.3, "loss_of_appetite": 0.4
    },
    "Common Cold": {
        "cough": 0.8, "sore_throat": 0.7, "headache": 0.4, "fever": 0.3,
        "fatigue": 0.4, "body_ache": 0.3
    },
    "Influenza": {
        "fever": 0.8, "cough": 0.7, "body_ache": 0.75, "fatigue": 0.8,
        "headache": 0.5, "sore_throat": 0.4, "chills": 0.5
    },
    "Tuberculosis": {
        "cough": 0.9, "weight_loss": 0.8, "night_sweats": 0.75,
        "fatigue": 0.7, "fever": 0.5, "breathlessness": 0.4
    },
    "Anemia": {
        "fatigue": 0.9, "dizziness": 0.7, "breathlessness": 0.5,
        "headache": 0.4, "loss_of_appetite": 0.3
    },
    "Hypertension": {
        "headache": 0.6, "dizziness": 0.6, "breathlessness": 0.3,
        "fatigue": 0.4
    },
    "Diabetes": {
        "excessive_thirst": 0.85, "frequent_urination": 0.85,
        "fatigue": 0.6, "weight_loss": 0.4, "loss_of_appetite": 0.2
    },
    "Jaundice": {
        "yellowing_skin": 0.9, "fatigue": 0.6, "loss_of_appetite": 0.6,
        "vomiting": 0.4, "abdominal_pain": 0.4, "fever": 0.3
    },
    "Pneumonia": {
        "cough": 0.85, "fever": 0.8, "breathlessness": 0.75,
        "fatigue": 0.6, "chills": 0.4
    },
    "Skin Infection": {
        "skin_rash": 0.9, "fever": 0.2, "fatigue": 0.2
    },
    "Malnutrition": {
        "weight_loss": 0.85, "fatigue": 0.8, "loss_of_appetite": 0.6,
        "dizziness": 0.4
    },
    "Chickenpox": {
        "skin_rash": 0.95, "fever": 0.6, "fatigue": 0.5, "headache": 0.3
    },
}

NOISE_PROB = 0.04  # chance a random unrelated symptom is also present
RECORDS_PER_DISEASE = 150


def generate_record(disease):
    profile = DISEASE_PROFILES[disease]
    row = {}
    for symptom in SYMPTOMS:
        base_p = profile.get(symptom, NOISE_PROB)
        row[symptom] = 1 if random.random() < base_p else 0
    row["disease"] = disease
    return row


def main():
    rows = []
    for disease in DISEASE_PROFILES:
        for _ in range(RECORDS_PER_DISEASE):
            rows.append(generate_record(disease))

    df = pd.DataFrame(rows)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)  # shuffle
    df.to_csv("data/village_health_data.csv", index=False)
    print(f"Generated {len(df)} records for {len(DISEASE_PROFILES)} diseases.")
    print(df["disease"].value_counts())


if __name__ == "__main__":
    main()
