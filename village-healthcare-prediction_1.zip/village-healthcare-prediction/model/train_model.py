"""
train_model.py
---------------
Trains a Random Forest classifier to predict likely disease from
reported symptoms, evaluates it, and saves:
  - model/disease_model.pkl   (trained model)
  - model/symptom_list.pkl    (ordered list of symptom columns used)
  - images/confusion_matrix.png
  - images/feature_importance.png
"""

import pandas as pd
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix
)

df = pd.read_csv("data/village_health_data.csv")

X = df.drop(columns=["disease"])
y = df["disease"]
symptom_list = list(X.columns)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = RandomForestClassifier(
    n_estimators=200, max_depth=12, random_state=42
)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f"Test Accuracy: {acc*100:.2f}%\n")
print(classification_report(y_test, y_pred))

# Save model + symptom list
joblib.dump(model, "model/disease_model.pkl")
joblib.dump(symptom_list, "model/symptom_list.pkl")

# Confusion matrix plot
plt.figure(figsize=(12, 10))
cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=model.classes_, yticklabels=model.classes_)
plt.title("Confusion Matrix - Village Healthcare Disease Prediction")
plt.ylabel("Actual Disease")
plt.xlabel("Predicted Disease")
plt.xticks(rotation=45, ha="right")
plt.yticks(rotation=0)
plt.tight_layout()
plt.savefig("images/confusion_matrix.png", dpi=150)
plt.close()

# Feature importance plot
importances = pd.Series(model.feature_importances_, index=symptom_list)
importances = importances.sort_values(ascending=True)
plt.figure(figsize=(9, 8))
importances.plot(kind="barh", color="#2E7D32")
plt.title("Symptom Importance in Disease Prediction")
plt.xlabel("Importance Score")
plt.tight_layout()
plt.savefig("images/feature_importance.png", dpi=150)
plt.close()

print("\nSaved: model/disease_model.pkl, model/symptom_list.pkl")
print("Saved: images/confusion_matrix.png, images/feature_importance.png")
